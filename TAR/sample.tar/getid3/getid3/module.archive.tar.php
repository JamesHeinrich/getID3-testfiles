<?

class getid3_tar {

	function getid3_tar(&$fd, &$ThisFileInfo) {
		$ThisFileInfo["fileformat"] = "tar";
		$this->read_tar($fd, $ThisFileInfo);
		return false;
	}

	// Reads the tar-file
	function read_tar($fd, &$ThisFileInfo) {
		
		$header_length = 512;
		$unpack_header = "a100fname/a8mode/a8uid/a8gid/a12size/a12mtime/a8chksum/a1typflag/a100lnkname/a6magic/a2ver/a32uname/a32gname/a8devmaj/a8devmin/a155/prefix";
		
		@fseek($fd, 0);
		//echo $this->unpack_header."<hr>";
		//$this->unpack_header = preg_replace( "/\s/", "" , $this->unpack_header);
		//echo $this->unpack_header."<hr>";
		while(!@feof($fd)) {
			$buffer = @fread($fd, $header_length);
			// check the block
			$checksum = 0;
			for($i=0;$i<148;$i++) {
				$checksum += Ord(substr($buffer, $i, 1));
			}
			for($i=148;$i<156;$i++) {
				$checksum += Ord(" ");
			}
			for($i=156;$i<512;$i++) {
				$checksum += Ord(substr($buffer, $i, 1));
			}
			$attr = unpack($unpack_header, $buffer);
			$name    = trim($attr["fname"]);
			$mode    = OctDec(trim($attr["mode"]));
			$uid     = OctDec(trim($attr["uid"]));
			$gid     = OctDec(trim($attr["gid"]));
			$size    = OctDec(trim($attr["size"]));
			$mtime   = OctDec(trim($attr["mtime"]));
			$chksum  = OctDec(trim($attr["chksum"]));
			$typflag   = trim($attr["typflag"]);
			$lnkname = trim($attr["lnkname"]);
			$magic   = trim($attr["magic"]);
			$ver     = trim($attr["ver"]);
			$uname   = trim($attr["uname"]);
			$gname   = trim($attr["gname"]);
			$devmaj  = OctDec(trim($attr["devmaj"]));
			$devmin  = OctDec(trim($attr["devmin"]));
			$prefix  = trim($attr["prefix"]);
			// EOF Found
			if(($checksum == 256) && ($chksum == 0)) {
				break;
			}
			if($prefix) {
				$name = $prefix."/".$name;
			}
			if((preg_match("#/$#", $name)) && !$name) {
				$typeflag = 5;
			}
			// If it's the end of the tar-file...
			$test = $this->repeat_string("\0", 512);
			if($buffer == $test) {
				break;
			}
			// Read the next chunk
			$data = @fread( $fd, $size );
			if(strlen($data) != $size) {
				@fclose($fd);
				$ThisFileInfo["error"][] = "Read error on tar file";
			}
			$diff = $size % 512;
			if($diff != 0) {
				// Padding, throw away
				@fread($fd, (512 - $diff));
			}
			// Protect against tar-files with garbage at the end
			if($name == "") {
				break;
			}
			$arr_typeflag = $this->get_flag_type();
			$typflag = $arr_typeflag["$typflag"];
			$ThisFileInfo["files"]["$name"] = array (
				"name"     => $name,
				"mode"     => $this->display_perms($mode)." (".$mode.")",
				"uid"      => $uid,
				"gid"      => $gid,
				"size"     => $size,
				"mtime"    => $mtime." (".date("m/d/Y H:i:s", $mtime).")",
				"chksum"   => $chksum,
				"typeflag" => $typflag,
				"linkname" => $lnkname,
				"magic"    => $magic,
				"version"  => $ver,
				"uname"    => $uname,
				"gname"    => $gname,
				"devmajor" => $devmaj,
				"devminor" => $devmin
				//"prefix"   => htmlspecialchars($prefix),
				//"data"     => htmlspecialchars($data)
			);
		}
	}
	
	// Builds a repititive string
	function repeat_string($string="", $num=0) {
		$ret = "";
		for($i=0;$i<$num;$i++) {
			$ret .= $string;
		}
		return $ret;
	}
	
	// Parses the file mode to file permissions
	function display_perms($mode) {
		// Determine Type
		if($mode & 0x1000)     $type="p"; // FIFO pipe
		elseif($mode & 0x2000) $type="c"; // Character special
		elseif($mode & 0x4000) $type="d"; // Directory
		elseif($mode & 0x6000) $type="b"; // Block special
		elseif($mode & 0x8000) $type="-"; // Regular
		elseif($mode & 0xA000) $type="l"; // Symbolic Link
		elseif($mode & 0xC000) $type="s"; // Socket
		else                   $type="u"; // UNKNOWN

		// Determine permissions
		$owner["read"]    = ($mode & 00400) ? "r" : "-";
		$owner["write"]   = ($mode & 00200) ? "w" : "-";
		$owner["execute"] = ($mode & 00100) ? "x" : "-";
		$group["read"]    = ($mode & 00040) ? "r" : "-";
		$group["write"]   = ($mode & 00020) ? "w" : "-";
		$group["execute"] = ($mode & 00010) ? "x" : "-";
		$world["read"]    = ($mode & 00004) ? "r" : "-";
		$world["write"]   = ($mode & 00002) ? "w" : "-";
		$world["execute"] = ($mode & 00001) ? "x" : "-";

		// Adjust for SUID, SGID and sticky bit
		if($mode & 0x800) $owner["execute"] = ($owner["execute"] == "x") ? "s" : "S";
		if($mode & 0x400) $group["execute"] = ($group["execute"] == "x") ? "s" : "S";
		if($mode & 0x200) $world["execute"] = ($world["execute"] == "x") ? "t" : "T";

		$s  = sprintf("%1s", $type);
		$s .= sprintf("%1s%1s%1s",   $owner["read"], $owner["write"], $owner["execute"]);
		$s .= sprintf("%1s%1s%1s",   $group["read"], $group["write"], $group["execute"]);
		$s .= sprintf("%1s%1s%1s\n", $world["read"], $world["write"], $world["execute"]);
		return $s;
	}

	// Converts the file type
	function get_flag_type() {
		return array(
		  "0" => "LF_NORMAL",
		  "1" => "LF_LINK",
			"2" => "LF_SYNLINK",
			"3" => "LF_CHR",
			"4" => "LF_BLK",
			"5" => "LF_DIR",
			"6" => "LF_FIFO",
			"7" => "LF_CONFIG",
			"D" => "LF_DUMPDIR",
			"K" => "LF_LONGLINK",
			"L" => "LF_LONGNAME",
			"M" => "LF_MULTIVOL",
			"N" => "LF_NAMES",
			"S" => "LF_SPARSE",
			"V" => "LF_VOLHDR"
		);
	}

}

?>
