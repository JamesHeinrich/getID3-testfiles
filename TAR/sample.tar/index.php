<?
	error_reporting(0);
	@set_time_limit(0);
	
	global $fn;

	require_once("getid3/getid3/getid3.php");

	$fn = urldecode($fn);
	if(empty($fn)) $fn = "sample.tar";

?>
<html>
<head>
<title>File Manager. File Info.</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<link rel="stylesheet" href="style.css">
</head>
<body bgcolor=#D2D2D2 marginwidth="0" marginheight="0" leftmargin="0" topmargin="0">

<table cellpadding="0" cellspacing="0" width="100%" border="0">
	<tr bgcolor="#000099">
		<td>
			<table cellpadding="0" cellspacing="0" width="100%" border="1" height="24">
				<tr bgcolor="#000099">
					<td class="textyellb">&nbsp;&nbsp;<?=$fn?></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?
	$getID3 = new getID3;
	$fileinfo = $getID3->analyze($fn);
?>
<table cellpadding="10" cellspacing="0" width="100%">
	<tr>
		<td><?=printArrayStructureTable($fileinfo)?></td>
	</tr>
</table>

</body>
</html>

<?
	
	function printArrayStructureTable($arr, $level=0) {
		
		$IMG_FLD = "<img src=\"images/f_fld.gif\" border=0";
		$IMG_OTH = "<img src=\"images/f_oth.gif\" border=0";

		reset($arr);
		while(list($keys, $vals) = each($arr)) {
			echo "<table border=0 cellpadding=0 cellspacing=1>";
	    if($level == 0) {
      	if(is_array($vals)) {
					echo "<td>".$IMG_FLD."&nbsp;</td>";
				} else {
					echo "<td>".$IMG_OTH."&nbsp;</td>";
				}
			}
			for($i=0;$i<$level;$i++) {
				if($i < ($level - 1)) {
					echo "<td>&nbsp;&nbsp;&nbsp;</td>";
				} else {
					if(is_array($vals)) {
						echo "<td>&nbsp;&nbsp;&nbsp;".$IMG_FLD."&nbsp;</td>";
					} else {
						echo "<td>&nbsp;&nbsp;&nbsp;".$IMG_OTH."&nbsp;</td>";
					}
				}
			}
			echo "<td>".$keys."</td>";
			if(is_array($vals)) {
				$level++;
				printArrayStructureTable($vals, $level);
				$level--;
			} else {
				echo "<td>&nbsp;=&nbsp;<b>".$vals."</a></td></tr>";
				echo "</table>";
			}
		}
	}
?>