<?php
/////////////////////////////////////////////////////////////////
/// getID3() by James Heinrich <getid3@users.sourceforge.net>  //
//        available at http://getid3.sourceforge.net          ///
/////////////////////////////////////////////////////////////////
//                                                             //
// getid3.nsv.php - part of getID3()                           //
// See getid3.readme.txt for more details                      //
//                                                             //
/////////////////////////////////////////////////////////////////

function getNSVHeaderFilepointer(&$fd, &$MP3fileInfo) {
	rewind($fd);
	$NSVheader = fread($fd, 4);

	switch ($NSVheader) {
		case 'NSVs':
			if (getNSVsHeaderFilepointer($fd, $MP3fileInfo, 0)) {
				$MP3fileInfo['fileformat'] = 'nsv';
			}
			break;

		case 'NSVf':
			if (getNSVfHeaderFilepointer($fd, $MP3fileInfo, 0)) {
				$MP3fileInfo['fileformat'] = 'nsv';
				getNSVsHeaderFilepointer($fd, $MP3fileInfo, $MP3fileInfo['nsv']['NSVf']['header_length']);
			}
			break;

		default:
			$MP3fileInfo['error'] .= "\n".'unknown NSV file header ('.$NSVheader.')';
			return FALSE;
			break;
	}

	return TRUE;
}

function getNSVsHeaderFilepointer(&$fd, &$MP3fileInfo, $fileoffset) {
	fseek($fd, $fileoffset, SEEK_SET);
	$NSVsheader = fread($fd, 28);
	$offset = 0;

	$MP3fileInfo['nsv']['NSVs']['identifier']      =                  substr($NSVsheader, $offset, 4);
	$offset += 4;

	if ($MP3fileInfo['nsv']['NSVs']['identifier'] != 'NSVs') {
		$MP3fileInfo['error'] .= "\n".'expected "NSVs" at offset ('.$fileoffset.'), found "'.$MP3fileInfo['nsv']['NSVs']['identifier'].'" instead';
		unset($MP3fileInfo['nsv']['NSVs']);
		return FALSE;
	}

	$MP3fileInfo['nsv']['NSVs']['offset']          = $fileoffset;

	$MP3fileInfo['nsv']['NSVs']['video_codec']     =                  substr($NSVsheader, $offset, 4);
	$offset += 4;
	$MP3fileInfo['nsv']['NSVs']['audio_codec']     =                  substr($NSVsheader, $offset, 4);
	$offset += 4;
	$MP3fileInfo['nsv']['NSVs']['resolution_x']    = LittleEndian2Int(substr($NSVsheader, $offset, 2));
	$offset += 2;
	$MP3fileInfo['nsv']['NSVs']['resolution_y']    = LittleEndian2Int(substr($NSVsheader, $offset, 2));
	$offset += 2;

	$MP3fileInfo['nsv']['NSVs']['framerate_index'] = LittleEndian2Int(substr($NSVsheader, $offset, 2));
	$offset += 1;
	$MP3fileInfo['nsv']['NSVs']['unknown1b']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
	$offset += 1;
	$MP3fileInfo['nsv']['NSVs']['unknown1c']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
	$offset += 1;
	$MP3fileInfo['nsv']['NSVs']['unknown1d']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
	$offset += 1;
	$MP3fileInfo['nsv']['NSVs']['unknown2a']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
	$offset += 1;
	$MP3fileInfo['nsv']['NSVs']['unknown2b']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
	$offset += 1;
	$MP3fileInfo['nsv']['NSVs']['unknown2c']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
	$offset += 1;
	$MP3fileInfo['nsv']['NSVs']['unknown2d']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
	$offset += 1;

	switch ($MP3fileInfo['nsv']['NSVs']['audio_codec']) {
		case 'PCM ':
			$MP3fileInfo['nsv']['NSVs']['bits_channel']    = LittleEndian2Int(substr($NSVsheader, $offset, 1));
			$offset += 1;
			$MP3fileInfo['nsv']['NSVs']['channels']        = LittleEndian2Int(substr($NSVsheader, $offset, 1));
			$offset += 1;
			$MP3fileInfo['nsv']['NSVs']['sample_rate']     = LittleEndian2Int(substr($NSVsheader, $offset, 2));
			$offset += 2;

			$MP3fileInfo['frequency']                      = $MP3fileInfo['nsv']['NSVs']['sample_rate'];
			break;

		case 'MP3 ':
		case 'NONE':
		default:
			$MP3fileInfo['nsv']['NSVs']['unknown3a']       = LittleEndian2Int(substr($NSVsheader, $offset, 1));
			$offset += 1;
			$MP3fileInfo['nsv']['NSVs']['unknown3b']       = LittleEndian2Int(substr($NSVsheader, $offset, 1));
			$offset += 1;
			$MP3fileInfo['nsv']['NSVs']['unknown3c']       = LittleEndian2Int(substr($NSVsheader, $offset, 1));
			$offset += 1;
			$MP3fileInfo['nsv']['NSVs']['unknown3d']       = LittleEndian2Int(substr($NSVsheader, $offset, 1));
			$offset += 1;
			break;
	}

	$MP3fileInfo['resolution_x']             = $MP3fileInfo['nsv']['NSVs']['resolution_x'];
	$MP3fileInfo['resolution_y']             = $MP3fileInfo['nsv']['NSVs']['resolution_y'];
	$MP3fileInfo['nsv']['NSVs']['framerate'] = NSVframerateLookup($MP3fileInfo['nsv']['NSVs']['framerate_index']);
	$MP3fileInfo['frame_rate']               = $MP3fileInfo['nsv']['NSVs']['framerate'];

	return TRUE;
}

function getNSVfHeaderFilepointer(&$fd, &$MP3fileInfo, $fileoffset, $getTOCoffsets=FALSE) {
	fseek($fd, $fileoffset, SEEK_SET);
	$NSVfheader = fread($fd, 28);
	$offset = 0;

	$MP3fileInfo['nsv']['NSVf']['identifier']    =                  substr($NSVfheader, $offset, 4);
	$offset += 4;

	if ($MP3fileInfo['nsv']['NSVf']['identifier'] != 'NSVf') {
		$MP3fileInfo['error'] .= "\n".'expected "NSVf" at offset ('.$fileoffset.'), found "'.$MP3fileInfo['nsv']['NSVf']['identifier'].'" instead';
		unset($MP3fileInfo['nsv']['NSVf']);
		return FALSE;
	}

	$MP3fileInfo['nsv']['NSVs']['offset']        = $fileoffset;

	$MP3fileInfo['nsv']['NSVf']['header_length'] = LittleEndian2Int(substr($NSVfheader, $offset, 4));
	$offset += 4;
	$MP3fileInfo['nsv']['NSVf']['file_size']     = LittleEndian2Int(substr($NSVfheader, $offset, 4));
	$offset += 4;

	if ($MP3fileInfo['nsv']['NSVf']['file_size'] > $MP3fileInfo['filesize']) {
		$MP3fileInfo['error'] .= "\n".'truncated file - NSVf header indicates '.$MP3fileInfo['nsv']['NSVf']['file_size'].' bytes, file actually '.$MP3fileInfo['filesize'].' bytes';
	}

	$MP3fileInfo['nsv']['NSVf']['playtime_ms']   = LittleEndian2Int(substr($NSVfheader, $offset, 4));
	$offset += 4;
	$MP3fileInfo['nsv']['NSVf']['meta_size']     = LittleEndian2Int(substr($NSVfheader, $offset, 4));
	$offset += 4;
	$MP3fileInfo['nsv']['NSVf']['TOC_entries_1'] = LittleEndian2Int(substr($NSVfheader, $offset, 4));
	$offset += 4;
	$MP3fileInfo['nsv']['NSVf']['TOC_entries_2'] = LittleEndian2Int(substr($NSVfheader, $offset, 4));
	$offset += 4;

	$NSVfheader .= fread($fd, $MP3fileInfo['nsv']['NSVf']['meta_size'] + (4 * $MP3fileInfo['nsv']['NSVf']['TOC_entries_1']) + (4 * $MP3fileInfo['nsv']['NSVf']['TOC_entries_2']));
	$NSVfheaderlength = strlen($NSVfheader);
	$MP3fileInfo['nsv']['NSVf']['metadata']      =                  substr($NSVfheader, $offset, $MP3fileInfo['nsv']['NSVf']['meta_size']);
	$offset += $MP3fileInfo['nsv']['NSVf']['meta_size'];

	if ($getTOCoffsets) {
		$TOCcounter = 0;
		while ($TOCcounter < $MP3fileInfo['nsv']['NSVf']['TOC_entries_1']) {
			if ($TOCcounter < $MP3fileInfo['nsv']['NSVf']['TOC_entries_1']) {
				$MP3fileInfo['nsv']['NSVf']['TOC_1'][$TOCcounter] = LittleEndian2Int(substr($NSVfheader, $offset, 4));
				$offset += 4;
				$TOCcounter++;
			}
		}
	}

	if (trim($MP3fileInfo['nsv']['NSVf']['metadata']) != '') {
		$CommentPairArray = explode('` ', $MP3fileInfo['nsv']['NSVf']['metadata']);
		foreach ($CommentPairArray as $CommentPair) {
			if (strstr($CommentPair, '=`')) {
				list($key, $value) = explode('=`', $CommentPair, 2);
				$MP3fileInfo['nsv']['comments'][strtolower($key)] = str_replace('`', '', $value);
			} else if (strstr($CommentPair, '='.chr(1))) {
				list($key, $value) = explode('='.chr(1), $CommentPair, 2);
				$MP3fileInfo['nsv']['comments'][strtolower($key)] = str_replace(chr(1), '', $value);
			}
		}
	}

	$MP3fileInfo['playtime_seconds'] = $MP3fileInfo['nsv']['NSVf']['playtime_ms'] / 1000;
	//$MP3fileInfo['bitrate']          = (($MP3fileInfo['nsv']['NSVf']['file_size'] - $MP3fileInfo['nsv']['NSVs']['offset']) * 8) / $MP3fileInfo['playtime_seconds'];
	$MP3fileInfo['bitrate']          = ($MP3fileInfo['nsv']['NSVf']['file_size'] * 8) / $MP3fileInfo['playtime_seconds'];

	return TRUE;
}

function NSVframerateLookup($framerateindex) {
	if ($framerateindex <= 127) {
		return (float) $framerateindex;
	}

	static $NSVframerateLookup = array();
	if (count($NSVframerateLookup) < 1) {
		$NSVframerateLookup[129] = (float) 29.970;
		$NSVframerateLookup[131] = (float) 23.976;
		$NSVframerateLookup[133] = (float) 14.985;
		$NSVframerateLookup[197] = (float) 59.940;
		$NSVframerateLookup[199] = (float) 47.952;
	}
	return (isset($NSVframerateLookup[$framerateindex]) ? $NSVframerateLookup[$framerateindex] : FALSE);
}

?>