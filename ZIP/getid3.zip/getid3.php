<?php
/////////////////////////////////////////////////////////////////
/// getID3() by James Heinrich <getid3@users.sourceforge.net>  //
//        available at http://getid3.sourceforge.net          ///
/////////////////////////////////////////////////////////////////
//                                                             //
// Requires: PHP 4.1.0 (or higher)                             //
//           GD  <1.6 for GIF and JPEG functions               //
//           GD >=1.6 for PNG and JPEG functions               //
//           GD >=2.0 for BMP display function                 //
//                                                             //
// Please see getid3.readme.txt for more information           //
//                                                             //
/////////////////////////////////////////////////////////////////

// Defines
define('GETID3VERSION', '1.5.7');
define('FREAD_BUFFER_SIZE', 16384); // number of bytes to read in at once

// Get base path of getID3()
$includedfilepaths = get_included_files();
foreach ($includedfilepaths as $key => $val) {
	if (basename($val) == 'getid3.php') {
		define('GETID3_INCLUDEPATH', dirname($val).'/');
	}
}
if (!defined('GETID3_INCLUDEPATH')) {
	define('GETID3_INCLUDEPATH', '');
}


function GetAllMP3info($filename, $assumedFormat='', $allowedFormats=array(), $MD5file=FALSE, $MD5data=FALSE) {
	require_once(GETID3_INCLUDEPATH.'getid3.functions.php'); // Function library

	$MP3fileInfo['getID3version']   = GETID3VERSION;
	$MP3fileInfo['fileformat']      = ''; // filled in later
	$MP3fileInfo['error']           = ''; // filled in later, unset if not used
	$MP3fileInfo['exist']           = FALSE;

	if (eregi('^(ht|f)tp://', $filename)) {

		// remote file
		$MP3fileInfo['filename'] = $filename;
		$MP3fileInfo['error'] = "\n".'Remote files are not supported in this version of getID3() - please copy the file locally first';

	} else {

		// local file

		$MP3fileInfo['filename']     = basename($filename);
		$MP3fileInfo['filepath']     = str_replace('\\', '/', realpath(dirname($filename)));
		$MP3fileInfo['filenamepath'] = $MP3fileInfo['filepath'].'/'.$MP3fileInfo['filename'];
		ob_start();
		if ($localfilepointer = fopen($filename, 'rb')) {

			$MP3fileInfo['exist'] = TRUE;
			clearstatcache();
			$MP3fileInfo['filesize'] = filesize($filename);

		} else {

			$MP3fileInfo['error'] .= "\n".'Error opening file: '.trim(strip_tags(ob_get_contents()));
			ob_end_clean();
			unset($MP3fileInfo['fileformat']);
			return $MP3fileInfo;

		}
		ob_end_clean();

	}

	$MP3fileInfo['audiodataoffset'] = 0;
	$MP3fileInfo['audiodataend']    = $MP3fileInfo['filesize'];

	//$formattest = fread($localfilepointer, 16);  // 16 bytes is sufficient for any format except ISO CD-image
	$formattest = fread($localfilepointer, 32774); // (ISO needs at least 32774 bytes)

	if ($DeterminedFormat = GetFileFormat($formattest)) {

		// supported format signature pattern detected
		require_once(GETID3_INCLUDEPATH.$DeterminedFormat['include']);

		switch ($DeterminedFormat['format']) {
			case 'midi':
				if ($assumedFormat === FALSE) {
					// do not parse all MIDI tracks - much faster
					getMIDIHeaderFilepointer($localfilepointer, $MP3fileInfo, FALSE);
				} else {
					getMIDIHeaderFilepointer($localfilepointer, $MP3fileInfo);
				}
				break;

			case 'aac':
				if (!getAACADIFheaderFilepointer($localfilepointer, $MP3fileInfo)) {
					$dummy = $MP3fileInfo;
					unset($dummy['error']);
					if (getAACADTSheaderFilepointer($localfilepointer, $dummy)) {
						$MP3fileInfo = $dummy;
					}
				}
				break;

			case 'zip':
				getZIPHeaderFilepointer($localfilepointer, $MP3fileInfo, $filename);
				break;

			default:
				$VariableFunctionName = $DeterminedFormat['function'];
				$VariableFunctionName($localfilepointer, $MP3fileInfo);
				break;
		}

		require_once(GETID3_INCLUDEPATH.'getid3.ape.php');
		getAPEtagFilepointer($localfilepointer, $MP3fileInfo);

	} else if ((($assumedFormat == 'mp3') || (($assumedFormat == '') && ((substr($formattest, 0, 3) == 'ID3') || (substr(BigEndian2Bin(substr($formattest, 0, 2)), 0, 11) == '11111111111'))))) {

		// assume AAC-ADTS format
		require_once(GETID3_INCLUDEPATH.'getid3.aac.php');
		$dummy = $MP3fileInfo;
		if (getAACADTSheaderFilepointer($localfilepointer, $dummy)) {

			$MP3fileInfo = $dummy;

		} else {

			// it's not AAC-ADTS format, probably MP3
			require_once(GETID3_INCLUDEPATH.'getid3.mp3.php');
			getMP3headerFilepointer($localfilepointer, $MP3fileInfo, TRUE);

		}

		// Calculate audiobytes from audiodataoffset
		$MP3fileInfo['audiobytes'] = 0;
		if (isset($MP3fileInfo['audiodataoffset'])) {
			$MP3fileInfo['audiobytes'] = $MP3fileInfo['filesize'] - $MP3fileInfo['audiodataoffset'];
		}

		// Subtract 128 bytes from audiobytes if ID3v1 tag is present
		if (isset($MP3fileInfo['id3']['id3v1'])) {
			$MP3fileInfo['audiobytes'] -= 128;
		}

		// Subtract size of lyrics3tags
		if (isset($mp3info['lyrics3']['raw']['lyrics3tagsize'])) {
			$MP3fileInfo['audiobytes'] -= $mp3info['lyrics3']['raw']['lyrics3tagsize'];
		}

		// Set audio bytes to zero if negative -- this should not happen
		if ($MP3fileInfo['audiobytes'] <= 0) {
			unset($MP3fileInfo['audiobytes']);
		}

		// Calculate playtime from audiobytes etc
		if (!isset($MP3fileInfo['playtime_seconds']) && isset($MP3fileInfo['audiobytes']) && isset($MP3fileInfo['bitrate_audio']) && ($MP3fileInfo['bitrate_audio'] > 0)) {
			$MP3fileInfo['playtime_seconds'] = ($MP3fileInfo['audiobytes'] * 8) / $MP3fileInfo['bitrate_audio'];
		}

	} else {

		// unknown format, do nothing

	}

	if (isset($MP3fileInfo['fileformat'])) {

		// Calculate combined bitrate - audio + video
		$CombinedBitrate  = 0;
		$CombinedBitrate += (isset($MP3fileInfo['bitrate_audio']) ? $MP3fileInfo['bitrate_audio'] : 0);
		$CombinedBitrate += (isset($MP3fileInfo['bitrate_video']) ? $MP3fileInfo['bitrate_video'] : 0);
		if (($CombinedBitrate > 0) && !isset($MP3fileInfo['bitrate'])) {
			$MP3fileInfo['bitrate'] = $CombinedBitrate;
		}

		// Set playtime string
		if (isset($MP3fileInfo['playtime_seconds']) && ($MP3fileInfo['playtime_seconds'] > 0) && !isset($MP3fileInfo['playtime_string'])) {
			$MP3fileInfo['playtime_string'] = PlaytimeString($MP3fileInfo['playtime_seconds']);
		}

		// remove meaningless entries from unknown-format files
		if (!$MP3fileInfo['fileformat']) {
			unset($MP3fileInfo['fileformat']);
			unset($MP3fileInfo['audiodataoffset']);
			unset($MP3fileInfo['audiodataend']);
		}
	}

	// remove ['error'] key if no errors occurred
	if (isset($MP3fileInfo['error']) && !$MP3fileInfo['error']) {
		unset($MP3fileInfo['error']);
	}

	// copy commonly used keys such as aritst, title, album, etc to root for easy access
	// these entries appear in order of precedence - ID3v2 (if present) will override ID3v1, for example
	if (isset($MP3fileInfo['asf'])) {
		CopyHandyKeysToRoot($MP3fileInfo['asf'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['ape'])) {
		CopyHandyKeysToRoot($MP3fileInfo['ape'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['id3']['id3v2'])) {
		CopyHandyKeysToRoot($MP3fileInfo['id3']['id3v2'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['id3']['id3v1'])) {
		CopyHandyKeysToRoot($MP3fileInfo['id3']['id3v1'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['ogg'])) {
		CopyHandyKeysToRoot($MP3fileInfo['ogg'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['vqf'])) {
		CopyHandyKeysToRoot($MP3fileInfo['vqf'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['RIFF'])) {
		CopyHandyKeysToRoot($MP3fileInfo['RIFF'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['quicktime'])) {
		CopyHandyKeysToRoot($MP3fileInfo['quicktime'], $MP3fileInfo);
	} else if (isset($MP3fileInfo['nsv']['comments'])) {
		CopyHandyKeysToRoot($MP3fileInfo['nsv']['comments'], $MP3fileInfo);
	}

	// Convert track number to integer (ID3v2 track numbers could be returned as a
	// string ('03' for example) - this will ensure all track numbers are integers
	if (isset($MP3fileInfo['track'])) {
		$MP3fileInfo['track'] = (int) $MP3fileInfo['track'];
	}

	// Get the MD5 hash of the entire file
	if ($MD5file) {
		$MP3fileInfo['md5_file'] = md5_file($filename);
	}

	// Get the MD5 hash of the audio/video portion of the file
	// (without ID3/APE/Lyrics3/etc header/footer tags
	if ($MD5data) {
		// first try and create a temporary file in the same directory as the file being scanned
		if (($dataMD5filename = tempnam('.', eregi_replace('[^[:alnum:]]', '', dirname($filename)))) === FALSE) {
			// if that fails, create a temporary file in the system temp directory
			$dataMD5filename = tempnam('//', 'getID3');
		}
		$MP3fileInfo['md5_data'] = FALSE;
		if ($MD5fp = @fopen($dataMD5filename, 'wb')) {
			fseek($localfilepointer, $MP3fileInfo['audiodataoffset'], SEEK_SET);
			$byteslefttowrite = $MP3fileInfo['audiodataend'] - $MP3fileInfo['audiodataoffset'];
			while (($byteslefttowrite > 0) && ($buffer = fread($localfilepointer, FREAD_BUFFER_SIZE))) {
				$byteslefttowrite -= fwrite($MD5fp, $buffer, $byteslefttowrite);
			}
			fclose($MD5fp);
			$MP3fileInfo['md5_data'] = md5_file($dataMD5filename);
		}
		unlink($dataMD5filename);
	}

	// close & remove local filepointer
	if (isset($localfilepointer) && is_resource($localfilepointer) && (get_resource_type($localfilepointer) == 'file')) {
		fclose($localfilepointer);
		if (isset($localfilepointer)) {
			unset($localfilepointer);
		}
	}

	return $MP3fileInfo;
}

function CopyHandyKeysToRoot(&$SourceArray, &$MP3fileInfo) {
	static $handyaccesskeystocopy = array('title', 'artist', 'album', 'year', 'genre', 'comment', 'track');
	foreach ($handyaccesskeystocopy as $keytocopy) {
		if (isset($SourceArray["$keytocopy"])) {
			$MP3fileInfo["$keytocopy"] = $SourceArray["$keytocopy"];
		}
	}
	return TRUE;
}

function GetFileFormat(&$filedata) {
	// this function will determine the format of a file based on usually
	// the first 2-4 bytes of the file (8 bytes for PNG, 16 bytes for JPG,
	// and in the case of ISO CD image, 6 bytes offset 32kb from the start
	// of the file).

	// Array containing information about all supported formats
	static $format_info = array();
	if (count($format_info) < 1) {
	    $format_info = array(
			// Format:  <internal name> => array(<regular expression to id file>, <include-file>, <function-to-call>)


			// Audio formats

			// AAC  - audio       - Advanced Audio Coding (AAC) - ADIF format
			$format_info['aac']  = array('^ADIF',  'getid3.aac.php', 'getAACADIFheaderFilepointer'),

			// AIFF - audio       - Audio Interchange File Format (AIFF)
			$format_info['aiff'] = array('^FORM', 'getid3.aiff.php', 'getAIFFHeaderFilepointer'),

			// FLAC - audio       - Free Lossless Audio Codec
			$format_info['flac'] = array('^fLaC', 'getid3.flac.php', 'getFLACHeaderFilepointer'),

			// LA   - audio       - Lossless Audio (LA)
			$format_info['la']   = array('^LA0[23]', 'getid3.la.php', 'getLAHeaderFilepointer'),

			// MIDI - audio       - MIDI (Musical Instrument Digital Interface)
			$format_info['midi'] = array('^MThd', 'getid3.midi.php', 'getMIDIHeaderFilepointer'),

			// MAC  - audio       - Monkey's Audio Compressor
			$format_info['mac']  = array('^MAC ', 'getid3.ape.php', 'getMonkeysAudioHeaderFilepointer'),

			// MPC  - audio       - Musepack / MPEGplus
			$format_info['mpc']  = array('^MP\+', 'getid3.mpc.php', 'getMPCHeaderFilepointer'),

			// Ogg  - audio       - Ogg Vorbis
			$format_info['ogg']  = array('^OggS', 'getid3.ogg.php', 'getOggHeaderFilepointer'),

			// VQF  - audio       - transform-domain weighted interleave Vector Quantization Format (VQF)
			$format_info['vqf']  = array('^TWIN', 'getid3.vqf.php', 'getVQFHeaderFilepointer'),


			// Audio-Video formats

			// ASF  - audio/video - Advanced Streaming Format, Windows Media Video, Windows Media Audio
			$format_info['asf']  = array('^\x30\x26\xB2\x75\x8E\x66\xCF\x11\xA6\xD9\x00\xAA\x00\x62\xCE\x6C', 'getid3.asf.php', 'getASFHeaderFilepointer'),

			// RIFF - audio/video - Resource Interchange File Format (RIFF) / WAV / AVI / CD-audio / SDSS = renamed variant used by SmartSound QuickTracks (www.smartsound.com)
			$format_info['riff'] = array('^(RIFF|SDSS)', 'getid3.riff.php', 'getRIFFHeaderFilepointer'),

			// Real - audio/video - RealAudio, RealVideo
			$format_info['real'] = array('^\.RMF', 'getid3.real.php', 'getRealHeaderFilepointer'),

			// NSV  - audio/video - Nullsoft Streaming Video (NSV)
			$format_info['nsv']  = array('^NSV[sf]', 'getid3.nsv.php', 'getNSVHeaderFilepointer'),

			// MPEG - audio/video - MPEG (Moving Pictures Experts Group)
			$format_info['mpeg'] = array('^\x00\x00\x01\xBA', 'getid3.mpeg.php', 'getMPEGHeaderFilepointer'),

			// QT   - audio/video - Quicktime
			$format_info['quicktime'] = array('^.{4}(cmov|free|ftyp|mdat|moov|pnot|skip|wide)', 'getid3.quicktime.php', 'getQuicktimeHeaderFilepointer'),


			// Still-Image formats

			// BMP  - still image - Bitmap (Windows, OS/2; uncompressed, RLE8, RLE4)
			$format_info['bmp']  = array('^BM', 'getid3.bmp.php', 'getBMPHeaderFilepointer'),

			// GIF  - still image - Graphics Interchange Format
			$format_info['gif']  = array('^GIF', 'getid3.gif.php', 'getGIFHeaderFilepointer'),

			// JPEG - still image - Joint Photographic Experts Group (JPEG)
			$format_info['jpg']  = array('^\xFF\xD8\xFF', 'getid3.jpg.php', 'getJPGHeaderFilepointer'),

			// PNG  - still image - Portable Network Graphics (PNG)
			$format_info['png']  = array('^\x89\x50\x4E\x47\x0D\x0A\x1A\x0A', 'getid3.png.php', 'getPNGHeaderFilepointer'),

			// Data formats

			// EXE  - data        - EXEcutable program (EXE, COM)
			$format_info['exe']  = array('^MZ', 'getid3.exe.php', 'getEXEHeaderFilepointer'),

			// ISO  - data        - International Standards Organization (ISO) CD-ROM Image
			$format_info['iso']  = array('^.{32769}CD001', 'getid3.iso.php', 'getISOHeaderFilepointer'),

			// RAR  - data        - RAR compressed data
			$format_info['rar']  = array('^Rar\!', 'getid3.rar.php', 'getRARHeaderFilepointer'),

			// ZIP  - data        - ZIP compressed data
			$format_info['zip']  = array('^PK', 'getid3.zip.php', 'getZIPHeaderFilepointer'),

		);
	}

	// Identify file format - loop through $format_info and detect with reg expr
	foreach ($format_info as $format_name => $info) {

		// Using preg_match() instead of ereg() - much faster
		// The /s switch on preg_match() forces preg_match() NOT to treat
		// newline (0x0A) characters as special chars but do a binary match
		if (preg_match('/'.$info[0].'/s', $filedata)) {

			// Extract information
			$FormatData['format']   = $format_name;
			//$FormatData['pattern']  = $info[0];
			$FormatData['include']  = $info[1];
			$FormatData['function'] = $info[2];

			return $FormatData;

		}
	}
	return FALSE;
}

?>